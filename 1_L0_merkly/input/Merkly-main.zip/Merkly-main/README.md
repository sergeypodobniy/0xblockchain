# Merkly
Заполняем приватники, заполняем в конфиге сети источника и приемника. Запускаем main.py

Мини-обзор - https://www.youtube.com/watch?v=ia0b0DoCjLg

Мой тг канал - https://t.me/+gLVbeoLy7k0yNTNi

# merklydropchecker
check points in merkly
добавьте адреса в adresses.txt и тыкните запустить)
